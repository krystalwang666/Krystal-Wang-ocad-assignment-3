// Canvas setup
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// Shape class to organize shape properties and behavior
class Shape {
  constructor(x, y, size, color, speedX, speedY) {
    this.x = x;
    this.y = y;
    this.size = size;
    this.color = color;
    this.speedX = speedX;
    this.speedY = speedY;
    this.alpha = 0; // transparency for fade-in effect
  }

  // Draw shape with current properties
  draw() {
    ctx.globalAlpha = this.alpha;
    ctx.fillStyle = this.color;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  // Update shape position and handle bounce
  update() {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.x < 0 || this.x > canvas.width) this.speedX *= -1;
    if (this.y < 0 || this.y > canvas.height) this.speedY *= -1;
  }
}

// Array to store all shapes
let shapes = [];

// Initialize the scene with determinate set of shapes
function initShapes() {
  for (let i = 0; i < 10; i++) {
    shapes.push(new Shape(
      canvas.width / 2,
      canvas.height / 2,
      5 + i * 2,
      `hsl(${i * 36}, 100%, 50%)`,
      Math.random() * 2 - 1,
      Math.random() * 2 - 1
    ));
  }
}

// Gradually increase alpha using setInterval (indirect animation)
let fadeInInterval = setInterval(() => {
  shapes.forEach(shape => {
    if (shape.alpha < 1) shape.alpha += 0.01;
  });
}, 100);

// Add more random shapes after 10 seconds (indeterminate growth)
setTimeout(() => {
  for (let i = 0; i < 20; i++) {
    shapes.push(new Shape(
      Math.random() * canvas.width,
      Math.random() * canvas.height,
      10 + Math.random() * 15,
      `hsl(${Math.random() * 360}, 100%, 60%)`,
      Math.random() * 4 - 2,
      Math.random() * 4 - 2
    ));
  }
}, 10000);

// Begin fade-out transition at 25 seconds
setTimeout(() => {
  clearInterval(fadeInInterval);
  setInterval(() => {
    shapes.forEach(shape => {
      if (shape.alpha > 0) shape.alpha -= 0.005;
    });
  }, 100);
}, 25000);

// Main animation loop using requestAnimationFrame
function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  shapes.forEach(shape => {
    shape.update();
    shape.draw();
  });
  requestAnimationFrame(animate);
}

// Initialize and start animation
initShapes();
animate();